package bank;

import javax.persistence.*;

public class CreateCredit {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Credit credit = new Credit(1L);
      credit.setBalance(100F);
      em.persist(credit);
      tx.commit();
      em.close();
      emf.close();
      System.out.println("Credit created");
   }
}
