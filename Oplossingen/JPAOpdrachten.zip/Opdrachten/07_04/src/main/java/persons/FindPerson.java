package persons;

import java.util.*;

import javax.persistence.*;
import javax.persistence.criteria.*;

public class FindPerson {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence.createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();

      CriteriaBuilder cb = em.getCriteriaBuilder();
      
      CriteriaQuery<Person> cq = cb.createQuery(Person.class);

      // Selection: from Person as p
      Root<Person> p = cq.from(Person.class);

      // Projection: select p
      cq.select(p);

      // Restriction: where p.firstName = 'Homer' and p.lastName = 'Simpson'
      // cq.where(cb.and(cb.equal(p.get("firstName"),"Homer"),
      // cb.equal(p.get("lastName"),"Simpson")));

      List<Predicate> predicates = new ArrayList<>();
      predicates.add(cb.equal(p.get("firstName"), "Homer"));
      predicates.add(cb.equal(p.get("lastName"), "Simpson"));
      cq.where(predicates.toArray(new Predicate[0]));

      TypedQuery<Person> query = em.createQuery(cq);
      List<Person> persons = query.getResultList();
      for (Person person : persons) {
         System.out.println(person);
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
