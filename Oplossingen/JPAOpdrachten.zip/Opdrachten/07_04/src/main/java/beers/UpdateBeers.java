package beers;

import javax.persistence.*;

public class UpdateBeers {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx= em.getTransaction();
      tx.begin();
      Query query = em.createQuery("update Beer b set b.price = b.price*1.02");
      int result = query.executeUpdate();
      tx.commit();
      em.close();
      System.out.println(result  + " bieren aangepast");
   }
}
