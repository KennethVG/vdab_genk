package beers;

import java.util.*;
import javax.persistence.*;

public class FindBeers {
   private static EntityManager em;

   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      em = emf.createEntityManager();
      doQuery("Bieren tussen 5 en 8 graden","beers[5-8]");
      doQuery("Bieren van 4,6,8 en 10 graden","beers[4,6,8,10]");      
      doQuery("Bieren met de naam 'kriek'","beers[kriek]");
      doQuery("Bieren uit Gent","beers[gent]");
      doQuery("Tripels","beers[tripel]");
      doQuery("Soorten met bieren van 9 graden","category[9]");
      doQuery("Soorten met bieren van 9 graden (bis)","category[9]bis");
      doQuery("Brouwers met bieren van 10 graden","brewer[10]");
      doQuery("Brouwers met bieren van 10 graden (bis)","brewer[10]bis");
      doQuery("Brouwers die pils brouwen","brewer[pils]");
      doQuery("Brouwers die pils brouwen (bis)","brewer[pils]bis");
      doQuery("Aantal bieren per alcoholgehalte","report[alcohol]");
      doQuery("Bieren per gemeente","report[city]");
      doQuery("De sterkste bieren","beers[strongest]");
      doQuery("Gemiddelde prijs van alle pils bieren","averagePrice[pils]");
      
      em.close();
      emf.close();
   }

   private static void doQuery(String title, String queryName) {
      System.out.println("\n***" + title + "***");
      Query q = em.createNamedQuery(queryName);
      List<?> list = q.getResultList();
      for (Object o : list) {
         if (o instanceof Object[]) {
            Object[] or = (Object[]) o;
            for (Object ob : or) {
               System.out.print(ob + " ");
            }
            System.out.println();
         } else {
            System.out.println(o);
         }
      }
   }
}
