package beers;

import java.util.*;

import javax.persistence.*;
import javax.persistence.criteria.*;

public class BeerService {
   private EntityManagerFactory emf = Persistence
         .createEntityManagerFactory("course");

   public List<Beer> geBeersByCriteria(String name, float alcohol, String brewer, String category) {
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      CriteriaBuilder cb = em.getCriteriaBuilder();
      CriteriaQuery<Beer> cq = cb.createQuery(Beer.class);
      Root<Beer> b = cq.from(Beer.class);
      cq.select(b);
      
      List<Predicate> criteria = new ArrayList<Predicate>();
      if (name != null) {
         criteria.add(cb.equal(b.get("name"), name));
      }
      if (alcohol != 0) {
         criteria.add(cb.equal(b.get("alcohol"), alcohol));
      }
      if (brewer != null) {
         criteria.add(cb.equal(b.get("brewer").get("name"), brewer));
      }
      if (category != null) {
         criteria.add(cb.equal(b.get("category").get("name"), category));
      }
      cq.where(criteria.toArray(new Predicate[0]));
      TypedQuery<Beer> q = em.createQuery(cq);
      List<Beer> result = q.getResultList();
      tx.commit();
      em.close();
      emf.close();
      return result;
   }
}
