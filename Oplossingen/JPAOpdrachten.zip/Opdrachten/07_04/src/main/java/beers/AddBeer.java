package beers;

import javax.persistence.*;

public class AddBeer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Brewer brewer = em.getReference(Brewer.class,124);
      Category category = em.getReference(Category.class,59);
      
      Beer beer = new Beer();
      beer.setAlcohol(13);
      beer.setBrewer(brewer);
      brewer.getBeers().add(beer);
      beer.setCategory(category);
      category.getBeers().add(beer);
      beer.setName("Westvleteren kerstbier");
      beer.setPrice(5);
      beer.setStock(100);
      em.persist(beer);
      tx.commit();
      System.out.println(beer);
      System.out.println(beer.getBrewer());
      System.out.println(beer.getCategory());      
      em.close();
   }
}
