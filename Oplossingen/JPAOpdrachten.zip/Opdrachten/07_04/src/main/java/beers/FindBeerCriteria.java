package beers;

import java.util.*;

public class FindBeerCriteria {
   public static void main(String[] args) {
      BeerService bs = new BeerService();
      
      List<Beer> beers = bs.geBeersByCriteria(null,0,null,"Amber");
      for(Beer beer: beers) {
         System.out.println(beer);
      }
   }
}
