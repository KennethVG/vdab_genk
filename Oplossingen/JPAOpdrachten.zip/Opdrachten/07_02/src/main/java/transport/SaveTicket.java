package transport;

import java.util.*;

import javax.persistence.*;

public class SaveTicket {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      
      SubscriberTicket st = new SubscriberTicket();
      st.setName("Jan Jansen");
      st.setDeparture("Brussel");
      st.setArrival("Gent");
      st.setStart(new GregorianCalendar(2011,0,1));
      st.setEnd(new GregorianCalendar(2011,11,31));
      em.persist(st);

      FreeTicket ft = new FreeTicket();
      ft.setDeparture("Hasselt");
      ft.setArrival("Knokke");
      ft.setDate(new GregorianCalendar(2011,6,21));
      ft.setSponsor("NMBS");
      em.persist(ft);
      
      NormalTicket nt = new NormalTicket();
      nt.setDeparture("Aalst");
      nt.setArrival("Luik");
      nt.setDate(new GregorianCalendar(2011,3,20));
      nt.setPrice(5);      
      em.persist(nt);
      
      tx.commit();
      em.close();
      System.out.println("Saved");
   }
}
