package transport;

import javax.persistence.*;

public class FindTicket {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      String jpql = "select t from Ticket t where type(t) = transport.FreeTicket";
      TypedQuery<Ticket> query = em.createQuery(jpql,Ticket.class);      
      for(Ticket t: query.getResultList()) {
         System.out.println(t.getId() + ":" +t.getDeparture() + " - " + t.getArrival());
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
