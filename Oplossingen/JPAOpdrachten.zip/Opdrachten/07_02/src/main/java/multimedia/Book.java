package multimedia;

import javax.persistence.*;

@Entity
@Table(name="MM_BOOK")
public class Book extends MultiMedia {
   private int pages;

   public int getPages() {
      return pages;
   }

   public void setPages(int pages) {
      this.pages = pages;
   }

   @Override
   public String toString() {
      return String.format(
            "Book [pages=%s, getPublisher()=%s, getTitle()=%s, getAuthor()=%s, getDate()=%s, getId()=%s]", pages,
            getPublisher(), getTitle(), getAuthor(), getDate(), getId());
   }
   
}
