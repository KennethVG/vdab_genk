package multimedia;

import javax.persistence.*;

@Entity
public class DVD extends MultiMedia {
   private int subtitles;

   public int getSubtitles() {
      return subtitles;
   }

   public void setSubtitles(int subtitles) {
      this.subtitles = subtitles;
   }

   @Override
   public String toString() {
      return String.format(
            "DVD [subtitles=%s, getPublisher()=%s, getTitle()=%s, getAuthor()=%s, getDate()=%s, getId()=%s]", subtitles,
            getPublisher(), getTitle(), getAuthor(), getDate(), getId());
   }
   
}
