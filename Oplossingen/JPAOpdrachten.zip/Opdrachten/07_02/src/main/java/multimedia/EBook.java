package multimedia;

import javax.persistence.*;

@Entity
public class EBook extends Book {
   private String url;

   public String getUrl() {
      return url;
   }

   public void setUrl(String url) {
      this.url = url;
   }

   @Override
   public String toString() {
      return String.format(
            "EBook [url=%s, getPages()=%s, toString()=%s, getPublisher()=%s, getTitle()=%s, getAuthor()=%s, getDate()=%s, getId()=%s]",
            url, getPages(), super.toString(), getPublisher(), getTitle(), getAuthor(), getDate(), getId());
   }
   
}
