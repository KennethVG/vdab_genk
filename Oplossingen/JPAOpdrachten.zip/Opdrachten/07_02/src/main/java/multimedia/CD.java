package multimedia;

import javax.persistence.*;

@Entity
public class CD extends AudioVisual {
   private int tracks;

   public int getTracks() {
      return tracks;
   }

   public void setTracks(int tracks) {
      this.tracks = tracks;
   }

   @Override
   public String toString() {
      return String.format(
            "CD [tracks=%s, getDuration()=%s, getPublisher()=%s, getTitle()=%s, getAuthor()=%s, getDate()=%s, getId()=%s]",
            tracks, getDuration(), getPublisher(), getTitle(), getAuthor(), getDate(), getId());
   }
   
}
