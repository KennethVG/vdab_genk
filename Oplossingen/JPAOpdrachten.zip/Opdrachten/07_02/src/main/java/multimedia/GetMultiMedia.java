package multimedia;

import javax.persistence.*;

public class GetMultiMedia {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      
      MultiMedia mm = em.find(MultiMedia.class,32769L);
      System.out.println(mm.getAuthor() + " " +mm.getTitle());
      
      tx.commit();
      em.close();
   }
}
