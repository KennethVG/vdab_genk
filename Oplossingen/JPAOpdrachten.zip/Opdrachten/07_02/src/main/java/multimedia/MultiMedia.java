package multimedia;

import java.io.*;
import java.util.*;
import javax.persistence.*;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public abstract class MultiMedia implements Serializable {
   @Id
   @GeneratedValue(strategy=GenerationType.TABLE)
   private long id;
   
   private String title;
   private String author;
   @Temporal(TemporalType.DATE)
   private Calendar pubdate;   
   private String publisher;
   
   public String getPublisher() {
      return publisher;
   }
   public void setPublisher(String publisher) {
      this.publisher = publisher;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getAuthor() {
      return author;
   }
   public void setAuthor(String author) {
      this.author = author;
   }
   public Calendar getDate() {
      return pubdate;
   }
   public void setDate(Calendar date) {
      this.pubdate = date;
   }
   public long getId() {
      return id;
   }
   
}
