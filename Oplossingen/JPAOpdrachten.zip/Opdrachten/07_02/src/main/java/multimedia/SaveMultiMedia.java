package multimedia;

import java.util.*;
import javax.persistence.*;

public class SaveMultiMedia {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Book book = new Book();
      book.setAuthor("Noël Vaes");
      book.setDate(new GregorianCalendar());
      book.setPages(200);
      book.setPublisher("Myself");
      book.setTitle("Java Basics");
      em.persist(book);
      
      EBook ebook = new EBook();
      ebook.setAuthor("Noël Vaes");
      ebook.setDate(new GregorianCalendar());
      ebook.setPages(200);
      ebook.setPublisher("Myself");
      ebook.setTitle("Java Basics EBook version");
      ebook.setUrl("www.noel-vaes.be/ebook");
      em.persist(ebook);
      
      CD cd = new CD();
      cd.setAuthor("Noël Vaes");
      cd.setDate(Calendar.getInstance());
      cd.setDuration(34);
      cd.setPublisher("Noël Vaes Music Center");
      cd.setTitle("Limburgse gezangen");
      cd.setTracks(7);
      em.persist(cd);
      
      DVD dvd = new DVD();
      dvd.setAuthor("No�l Vaes");
      dvd.setDate(Calendar.getInstance());
      dvd.setPublisher("No�l Vaes Movie Center");
      dvd.setTitle("Kataflop");
      dvd.setSubtitles(4);
      em.persist(dvd);  
      
      tx.commit();
      em.close();
   }
}
