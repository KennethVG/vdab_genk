package multimedia;

import javax.persistence.*;

public class FindMultiMedia {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence.createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();

      TypedQuery<MultiMedia> query = em.createQuery("select m from MultiMedia as m where m.author='Noël Vaes'",
            MultiMedia.class);
      query.getResultList().forEach(System.out::println);

      tx.commit();
      em.close();
      emf.close();
   }
}
