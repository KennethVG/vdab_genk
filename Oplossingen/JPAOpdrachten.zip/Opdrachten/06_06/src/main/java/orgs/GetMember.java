package orgs;

import javax.persistence.*;

public class GetMember {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Member member = em.find(Member.class,1L);
      System.out.println(member.getName());
      for(Organisation organisation: member.getOrganisations()) {
         System.out.println(organisation.getName());
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
