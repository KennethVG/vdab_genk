package orgs;

import javax.persistence.*;

public class SaveOrganisation {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      
      Organisation org = new Organisation();
      org.setName("Moes club");
      
      Member member1 = new Member();
      member1.setName("Homer Simpson");
      
      Member member2 = new Member();
      member2.setName("Allen");
      
      org.getMembers().add(member1);
      org.getMembers().add(member2);
      
      member1.getOrganisations().add(org);
      member2.getOrganisations().add(org);
      
      em.persist(member1);
      em.persist(member2);
      em.persist(org);
      tx.commit();
      em.close();
      emf.close();
   }
}
