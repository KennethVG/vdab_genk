package orgs;

import java.util.*;

import javax.persistence.*;

@Entity
public class Organisation {
   @Id
   @GeneratedValue
   private long id;
   
   private String name;
   
   @ManyToMany(mappedBy="organisations")
   private Set<Member> members = new HashSet<Member>();

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Set<Member> getMembers() {
      return members;
   }

   public void setMembers(Set<Member> members) {
      this.members = members;
   }

   public void setId(long id) {
      this.id = id;
   }
}
