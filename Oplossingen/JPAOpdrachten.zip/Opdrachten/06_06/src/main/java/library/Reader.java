package library;

import java.util.*;

import javax.persistence.*;

@Entity
public class Reader {
   @Id
   @GeneratedValue
   private long id;
   
   private String name;
   
   @ManyToMany
   private Set<Magazine> magazines = new HashSet<Magazine>();

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Set<Magazine> getMagazines() {
      return magazines;
   }

   public void setMagazines(Set<Magazine> magazines) {
      this.magazines = magazines;
   }

   public void setId(long id) {
      this.id = id;
   }
}
