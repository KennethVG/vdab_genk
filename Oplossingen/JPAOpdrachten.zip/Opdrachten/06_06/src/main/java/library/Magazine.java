package library;

import javax.persistence.*;

@Entity
public class Magazine {
   @Id
   @GeneratedValue
   private long id;
   
   private String title;

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public long getId() {
      return id;
   }
   
   
}
