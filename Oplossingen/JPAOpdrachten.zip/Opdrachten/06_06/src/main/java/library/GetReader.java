package library;

import javax.persistence.*;

public class GetReader {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Reader reader = em.find(Reader.class,1L);
      System.out.println(reader.getName());
      for(Magazine book: reader.getMagazines()) {
         System.out.println(book.getTitle());
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
