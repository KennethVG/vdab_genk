package library;

import javax.persistence.*;

public class SaveReader {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Reader reader = new Reader();
      reader.setName("Homer");  
      Magazine magazine = new Magazine();
      magazine.setTitle("The Simpson Tales");
      reader.getMagazines().add(magazine);      
      em.persist(magazine);
      em.persist(reader);      
      tx.commit();
      em.close();
      emf.close();
   }
}
