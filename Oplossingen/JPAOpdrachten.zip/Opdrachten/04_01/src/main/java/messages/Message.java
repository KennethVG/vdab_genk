package messages;

import javax.persistence.*;

@Entity
public class Message {
   private long id;
   @Access(AccessType.FIELD)
   private String text;

   public Message() {
   }

   public Message(long id, String text) {
      this.id = id;
      this.text = text;
   }

   @Id
   public long getId() {
      return id;
   }

   public void setId(long id) {
      this.id = id;
   }

   public String getText() {
      return text;
   }

   public void setText(String text) {
      this.text = text;
   }
}
