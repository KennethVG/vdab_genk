package messages;

import javax.persistence.*;

public class GetMessage {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Message  message1 = em.find(Message.class,1L);
      System.out.println(message1.getText());
      Message  message2 = em.find(Message.class,2L);
      System.out.println(message2.getText());
      tx.commit();
      em.close();
   }
}
