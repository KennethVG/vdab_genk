package messages;

import javax.persistence.*;

public class ChangeMessage {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Message  message = em.find(Message.class,1L);
      message.setText("Hello Mars");
      tx.commit();
      message.setText("Hello Venus");      
      em.close();
      emf.close();
   }
}
