package beers;

import java.util.*;

import javax.persistence.*;

public class FindBeer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      TypedQuery<Beer> query  = em.createQuery("select br.beers from Brewer as br",Beer.class);
      List<Beer> result = query.getResultList();
      for(Beer b: result) {
         System.out.println(b);
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
