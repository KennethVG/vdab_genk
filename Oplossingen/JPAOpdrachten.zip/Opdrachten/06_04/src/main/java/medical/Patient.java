package medical;

import javax.persistence.*;

@Entity
public class Patient {
   @Id
   @GeneratedValue
   private long id;   
   private String name;
   
   @OneToOne(cascade={CascadeType.PERSIST,CascadeType.REMOVE}, orphanRemoval=true)
   @JoinColumn(name="MF_ID")
   private MedicalFile medicalFile;

   public long getId() {
      return id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public MedicalFile getMedicalFile() {
      return medicalFile;
   }

   public void setMedicalFile(MedicalFile medicalFile) {
      this.medicalFile = medicalFile;
   }   
   
   public void addMedicalFile(MedicalFile mf) {
      medicalFile = mf;
      mf.setPatient(this);
   }
}
