package medical;

import javax.persistence.*;

public class GetPatient{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Patient patient = em.find(Patient.class,2L);
      System.out.println(patient.getName());
      tx.commit();
      em.close();
      emf.close();
      System.out.println(patient.getMedicalFile().getHeight());
      System.out.println(patient.getMedicalFile().getWeight());      
   }
}
