package medical;

import javax.persistence.*;

public class RemoveMedicalFile{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      
      Patient patient = em.find(Patient.class,1);
      MedicalFile mf = patient.getMedicalFile();
      mf.setPatient(null);
      patient.setMedicalFile(null);
      
      tx.commit();
      em.close();
      emf.close();
   }
}
