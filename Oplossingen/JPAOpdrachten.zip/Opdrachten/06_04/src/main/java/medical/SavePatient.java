package medical;

import javax.persistence.*;

public class SavePatient{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Patient patient = new Patient();
      patient.setName("Tom Johnson");
      MedicalFile mf = new MedicalFile();
      mf.setHeight(1.75F);
      mf.setWeight(75);
      patient.addMedicalFile(mf);
      em.persist(mf);
      em.persist(patient);
      tx.commit();
      em.close();
      emf.close();
      System.out.println("Patient saved");
   }
}
