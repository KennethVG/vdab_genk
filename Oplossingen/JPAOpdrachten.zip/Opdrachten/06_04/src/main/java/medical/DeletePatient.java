package medical;

import javax.persistence.*;

public class DeletePatient{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Patient patient = em.getReference(Patient.class,1);
      em.remove(patient);
      tx.commit();
      em.close();
   }
}
