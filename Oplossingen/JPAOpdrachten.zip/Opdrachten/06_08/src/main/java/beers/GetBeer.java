package beers;

import javax.persistence.*;

public class GetBeer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Beer beer = em.find(Beer.class,229);
      System.out.println(beer.getName());
      System.out.println(beer.getBrewer().getName());
      System.out.println(beer.getCategory().getName());
      tx.commit();
      em.close();
      emf.close();
   }
}
