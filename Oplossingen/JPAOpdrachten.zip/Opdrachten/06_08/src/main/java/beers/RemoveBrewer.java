package beers;

import javax.persistence.*;

public class RemoveBrewer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Brewer brewer = em.getReference(Brewer.class,125);
      em.remove(brewer);
      tx.commit();
      em.close();
      emf.close();
   }
}
