package beers;

import javax.persistence.*;

public class GetBrewer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Brewer brewer = em.find(Brewer.class,125);
      System.out.println(brewer.getName());
      brewer.getBeers().forEach(System.out::println);
      tx.commit();
      em.close();
      emf.close();
   }
}
