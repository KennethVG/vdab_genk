package education;

import javax.persistence.*;

public class GetSchool {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      School school = em.find(School.class, 7L);
      for (Student s : school.getStudents()) {
         System.out.println(s.getName());
      }
      em.close();
      emf.close();
   }
}
