package education;

import javax.persistence.*;

@Entity
public class Student {
   @Id
   @GeneratedValue
   private long id;
   
   private String name;
   
   @ManyToOne
   private School school;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public School getSchool() {
      return school;
   }

   public void setSchool(School school) {
      this.school = school;
   }

   public long getId() {
      return id;
   }
   
}
