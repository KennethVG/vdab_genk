package education;

import javax.persistence.*;

public class GetStudent {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();

      Student student = em.find(Student.class, 1L);
      
      System.out.println(student.getName());
      System.out.println(student.getSchool().getName());
      
      tx.commit();
      em.close();
      emf.close();

   }
}
