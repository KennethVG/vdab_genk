package education;

import java.util.*;

import javax.persistence.*;

@Entity
public class School {
   @Id
   @GeneratedValue
   private long id;
      
   private String name;
   
   @OneToMany(mappedBy="school",cascade=CascadeType.PERSIST)
   @OrderBy("name DESC")
   //@OrderColumn(name="STUDENT_ORDER")
   private List<Student> students = new ArrayList<Student>();

   public List<Student> getStudents() {
      return students;
   }

   public void setStudents(List<Student> students) {
      this.students = students;
   }
  
   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public long getId() {
      return id;
   }

   public void addStudent(Student student) {
      students.add(student);
      student.setSchool(this);
   }
   
   public void removeStudent(Student student) {
      students.remove(student);
      student.setSchool(null);
   }
}
