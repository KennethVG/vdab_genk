package education;

import javax.persistence.*;

public class SaveSchool {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      
      School school = new School();
      
      school.setName("Springfield High School");
      Student s1 = new Student();
      s1.setName("Bart");
      s1.setSchool(school);
      
      Student s2 = new Student();
      s2.setName("Lisa");
      s2.setSchool(school);
      
      school.getStudents().add(s1);
      school.getStudents().add(s2);      
            
      em.persist(school);
      
      tx.commit();
      em.close();
      emf.close();
      
      System.out.println("Done");
   }
}
