package company;

public enum StaffRole {
   CEO,CIO,CTO,CFO,CMO;
}
