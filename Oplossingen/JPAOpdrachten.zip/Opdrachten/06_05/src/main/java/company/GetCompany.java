package company;

import javax.persistence.*;

public class GetCompany {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Company company = em.find(Company.class,1L);
      System.out.println(company.getName());
      System.out.println(company.getStaff().get(StaffRole.CEO).getName());
      tx.commit();
      em.close();
      emf.close();
   }
}
