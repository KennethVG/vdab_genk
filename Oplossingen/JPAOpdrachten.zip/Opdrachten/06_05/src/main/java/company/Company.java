package company;

import java.util.*;

import javax.persistence.*;

@Entity
public class Company {
   @Id
   @GeneratedValue
   private long id;

   private String name;

   @OneToMany(cascade=CascadeType.PERSIST)
   @MapKey(name="role")
   @JoinColumn
   private Map<StaffRole, StaffMember> staff = new HashMap<StaffRole, StaffMember>();

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Map<StaffRole, StaffMember> getStaff() {
      return staff;
   }

   public void setStaff(Map<StaffRole, StaffMember> staff) {
      this.staff = staff;
   }

   public void setId(long id) {
      this.id = id;
   }
}
