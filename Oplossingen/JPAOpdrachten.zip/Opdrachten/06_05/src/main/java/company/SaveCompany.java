package company;

import javax.persistence.*;

public class SaveCompany {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Company company = new Company();
      company.setName("The Simpsons");
      StaffMember member1 = new StaffMember();
      member1.setName("Homer");
      member1.setRole(StaffRole.CEO);
      StaffMember member2 = new StaffMember();
      member2.setName("Marge");
      member2.setRole(StaffRole.CTO);
      company.getStaff().put(member1.getRole(),member1);
      company.getStaff().put(member2.getRole(),member2);
      em.persist(company);
      tx.commit();
      em.close();
      emf.close();
   }
}
