package beers;

import java.util.*;

import javax.persistence.*;

public class FindBeer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Query query  = em.createQuery("select br.beers from Brewer as br");
      List result = query.getResultList();
      for(Object o: result) {
         System.out.println(o);
      }
      tx.commit();
      em.close();
   }
}
