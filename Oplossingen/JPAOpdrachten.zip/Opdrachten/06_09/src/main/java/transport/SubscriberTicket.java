package transport;

import java.util.*;

import javax.persistence.*;

@Entity
//@DiscriminatorValue("SUB")
public class SubscriberTicket extends Ticket{
   private String name;
   @Temporal(TemporalType.DATE)
   private Calendar start;
   @Temporal(TemporalType.DATE)
   private Calendar end;

   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public Calendar getStart() {
      return start;
   }
   public void setStart(Calendar start) {
      this.start = start;
   }
   public Calendar getEnd() {
      return end;
   }
   public void setEnd(Calendar end) {
      this.end = end;
   }
   
}
