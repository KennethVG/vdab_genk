package transport;

import java.util.*;

import javax.persistence.*;

@Entity
//@MappedSuperclass
//@DiscriminatorValue("OCCAS")
public abstract class OccasionalTicket extends Ticket {
   @Temporal(TemporalType.DATE)
   private Calendar date;

   public Calendar getDate() {
      return date;
   }

   public void setDate(Calendar date) {
      this.date = date;
   }   
}
