package university;

import java.util.*;

import javax.persistence.*;

public class SaveGraduate {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Graduate graduate = new Graduate();
      graduate.setName("Homer Simpson");
      Degree degree = new Degree();
      degree.setName("Master Beer Drinking");
      DegreeRelation degreeRelation = new DegreeRelation();
      degreeRelation.setDate(new Date());
      degreeRelation.setLevel(90);
      degreeRelation.setDegree(degree);
      graduate.getDegrees().add(degreeRelation);
      em.persist(degree);
      em.persist(degreeRelation);
      em.persist(graduate);
      tx.commit();
      em.close();
      emf.close();
   }
}
