package university;

import java.util.*;

import javax.persistence.*;

@Entity
public class DegreeRelation {
   @Id
   @GeneratedValue
   private long id;
   
   @Temporal(TemporalType.DATE)
   private Date date;
   private int level;
   
   @ManyToOne
   private Degree degree;

   public Date getDate() {
      return date;
   }

   public void setDate(Date date) {
      this.date = date;
   }

   public int getLevel() {
      return level;
   }

   public void setLevel(int level) {
      this.level = level;
   }

   public Degree getDegree() {
      return degree;
   }

   public void setDegree(Degree degree) {
      this.degree = degree;
   }

   public void setId(long id) {
      this.id = id;
   }
}
