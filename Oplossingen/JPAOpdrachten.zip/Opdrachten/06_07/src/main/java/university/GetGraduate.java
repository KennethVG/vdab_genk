package university;

import javax.persistence.*;

public class GetGraduate {
   public static void main(String[] args) throws Exception {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Graduate graduate = em.find(Graduate.class,1L);
      System.out.println(graduate.getName());
      for(DegreeRelation deg: graduate.getDegrees()) {
         System.out.println(deg.getDate());
         System.out.println(deg.getLevel());
         System.out.println(deg.getDegree().getName());
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
