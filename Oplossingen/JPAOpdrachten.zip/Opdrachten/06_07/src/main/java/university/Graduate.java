package university;

import java.util.*;

import javax.persistence.*;

@Entity
public class Graduate {
   @Id
   @GeneratedValue
   private long id;
   
   private String name;
   
   @OneToMany
   @JoinColumn
   private Set<DegreeRelation> degrees = new HashSet<DegreeRelation>();

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Set<DegreeRelation> getDegrees() {
      return degrees;
   }

   public void setDegrees(Set<DegreeRelation> degrees) {
      this.degrees = degrees;
   }

   public long getId() {
      return id;
   }
}
