package soccer;

import javax.persistence.*;

public class SavePlayer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Player player = new Player();
      player.setNumber(1);
      player.setClub("FC De Kampioenen");
      player.setName("Marske");
      em.persist(player);
      tx.commit();
      em.close();
      System.out.println("Speler bewaard");
   }
}
