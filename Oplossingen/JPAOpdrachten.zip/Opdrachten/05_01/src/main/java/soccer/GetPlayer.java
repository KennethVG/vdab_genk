package soccer;

import javax.persistence.*;

public class GetPlayer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      PlayerPK pk = new PlayerPK();
      pk.setClub("FC De Kampioenen");
      pk.setNumber(1);      
      Player player = em.find(Player.class,pk);
      System.out.println(player.getName());
      em.persist(player);
      tx.commit();
      em.close();
   }
}
