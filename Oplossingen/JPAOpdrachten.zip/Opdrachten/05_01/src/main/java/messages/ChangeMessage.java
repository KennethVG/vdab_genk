package messages;

import javax.persistence.*;

public class ChangeMessage {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Message  message = em.find(Message.class,1L);
      //em.detach(message);
      //em.clear()
      message.setText("Hello Mars");
      tx.commit();
      em.close();
      message.setText("Hello Venus");      
      emf.close();
   }
}
