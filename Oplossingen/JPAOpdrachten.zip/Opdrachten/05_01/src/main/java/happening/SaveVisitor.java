package happening;

import javax.persistence.*;

public class SaveVisitor {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Visitor visitor = new Visitor("Homer",43);
      em.persist(visitor);
      tx.commit();
      em.close();
      System.out.println(visitor.getId());
      System.out.println("Visitor saved");
   }
}
