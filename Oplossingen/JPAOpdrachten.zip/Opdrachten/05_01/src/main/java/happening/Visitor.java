package happening;

import javax.persistence.*;

@Entity
public class Visitor {
   @Id
   @GeneratedValue(strategy=GenerationType.TABLE)
   private long id;
   private String name;
   private int age;
   
   public Visitor() {      
   }
   
   public Visitor(String name, int age) {
      this.name = name;
      this.age = age;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public int getAge() {
      return age;
   }

   public void setAge(int age) {
      this.age = age;
   }

   public long getId() {
      return id;
   }
}
