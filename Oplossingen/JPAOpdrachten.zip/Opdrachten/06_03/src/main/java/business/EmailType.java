package business;

public enum EmailType {
   HOME,BUSINESS;
}
