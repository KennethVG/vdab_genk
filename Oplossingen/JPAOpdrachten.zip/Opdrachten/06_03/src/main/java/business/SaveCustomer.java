package business;

import javax.persistence.*;

public class SaveCustomer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Customer customer = new Customer();
      customer.setName("Homer Simpson");
      customer.getPhones().put("home","555 12369");
      customer.getPhones().put("mobile","555 777856");
      Email email1 = new Email();
      email1.setAddress("homer@springfield.com");
      Email email2 = new Email();
      customer.getEmails().put(EmailType.HOME,email1);
      email2.setAddress("homer@nuclearplant.com");
      customer.getEmails().put(EmailType.BUSINESS,email2);
      
      em.persist(customer);
      tx.commit();
      em.close();
      System.out.println("Saved");
   }
}
