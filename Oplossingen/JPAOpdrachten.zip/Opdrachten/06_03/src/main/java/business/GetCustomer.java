package business;

import javax.persistence.*;

public class GetCustomer {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Customer customer = em.find(Customer.class,1L);
      System.out.println(customer.getName());
      System.out.println(customer.getPhones().get("home"));
      System.out.println(customer.getEmails().get(EmailType.BUSINESS).getAddress());
      tx.commit();
      em.close();
   }
}
