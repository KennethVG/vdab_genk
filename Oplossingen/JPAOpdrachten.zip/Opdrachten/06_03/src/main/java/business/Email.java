package business;

import javax.persistence.*;

@Embeddable
public class Email {
   @Column(name="ADDRESS")
   private String address;

   public String getAddress() {
      return address;
   }

   public void setAddress(String address) {
      this.address = address;
   }
   
}
