package cooking;

import java.util.*;

import javax.persistence.*;

@Entity
public class Menu {
   @Id
   @GeneratedValue
   private int id;   
   private String title;
   
   @ElementCollection
   @CollectionTable(name="Ingredients")
   private Collection<Ingredient> ingredients = new ArrayList<Ingredient>();

   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public Collection<Ingredient> getIngredients() {
      return ingredients;
   }

   public void setIngredients(Collection<Ingredient> ingredients) {
      this.ingredients = ingredients;
   }
   
   
}
