package cooking;

import javax.persistence.*;

public class SaveMenu{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Menu menu = new Menu();
      menu.setTitle("Konijn met pruimen");
      menu.getIngredients().add(new Ingredient("Konijntje",1));
      menu.getIngredients().add(new Ingredient("Pruimen",8));
      menu.getIngredients().add(new Ingredient("Rode wijn",1));
      em.persist(menu);
      tx.commit();
      em.close();
      System.out.println("Menu bewaard");
   }
}
