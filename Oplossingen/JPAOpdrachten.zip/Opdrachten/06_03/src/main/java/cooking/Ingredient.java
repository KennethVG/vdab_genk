package cooking;

import javax.persistence.*;

@Embeddable
public class Ingredient {
   private int quantity;
   private String name;
   
   public Ingredient() {
      
   }
   
   public Ingredient(String name, int quantity) {
      this.name = name;
      this.quantity = quantity;
   }
   
   public int getQuantity() {
      return quantity;
   }
   public void setQuantity(int quantity) {
      this.quantity = quantity;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }   
}
