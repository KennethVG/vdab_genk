package cooking;

import javax.persistence.*;

public class GetMenu{
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      Menu menu = em.find(Menu.class, 1);
      System.out.println(menu.getTitle());
      for(Ingredient i: menu.getIngredients()) {
         System.out.format("%s : %d%n",i.getName(),i.getQuantity());
      }
      
      tx.begin();
      tx.commit();
      em.close();
   }
}
