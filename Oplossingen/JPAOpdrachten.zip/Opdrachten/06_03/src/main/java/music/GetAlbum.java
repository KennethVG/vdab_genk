package music;

import javax.persistence.*;

public class GetAlbum {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Album album = em.find(Album.class,1L);
      System.out.println(album.getTitle());
      System.out.println(album.getAuthor());
      for(String track: album.getTracks()) {
         System.out.println(track);         
      }
      tx.commit();
      em.close();
      emf.close();
   }
}
