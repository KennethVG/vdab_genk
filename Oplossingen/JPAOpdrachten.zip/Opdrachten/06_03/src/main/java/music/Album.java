package music;

import java.util.*;

import javax.persistence.*;

@Entity
public class Album {
   @Id   
   @GeneratedValue
   private long id;
   private String title;
   private String author;
   
   @ElementCollection
   @CollectionTable(name="Tracks")
   private List<String> tracks = new ArrayList<>();
   
   public long getId() {
      return id;
   }
   public void setId(long id) {
      this.id = id;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getAuthor() {
      return author;
   }
   public void setAuthor(String author) {
      this.author = author;
   }
   public List<String> getTracks() {
      return tracks;
   }
   public void setTracks(List<String> tracks) {
      this.tracks = tracks;
   }
}
