package music;

import javax.persistence.*;

public class SaveAlbum {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Album album = new Album();
      album.setTitle("Dark Horse");
      album.setAuthor("Nickelback");
      album.getTracks().add("Something in your mouth");
      album.getTracks().add("Burn it to the ground");
      album.getTracks().add("Gotta be somebody");
      album.getTracks().add("I'd come for you");
      album.getTracks().add("Next go round");
      album.getTracks().add("Never gonna be alone");
      album.getTracks().add("Shakin' hands");
      album.getTracks().add("S.E.X.");
      album.getTracks().add("If today was your last day");
      album.getTracks().add("This afternoon");
      em.persist(album);
      tx.commit();
      em.close();
      emf.close();
      System.out.println("Album saved");
   }
}
