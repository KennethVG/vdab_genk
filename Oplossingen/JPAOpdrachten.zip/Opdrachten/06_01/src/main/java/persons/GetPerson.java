package persons;

import java.text.*;
import javax.persistence.*;

public class GetPerson {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Person person = em.find(Person.class,1L);
      tx.commit();
      em.close();
      System.out.println(person.getFirstName());
      System.out.println(person.getLastName());
      SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
      System.out.println(sdf.format(person.getBirthDay().getTime()));
      //System.out.printf("%td/%<tm/%<tY",person.getBirthDay());
      System.out.println(person.getGender());
      System.out.println(person.getComment());      
   }
}
