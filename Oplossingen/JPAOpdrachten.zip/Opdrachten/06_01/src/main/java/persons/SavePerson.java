package persons;

import java.nio.file.*;
import java.util.GregorianCalendar;

import javax.persistence.*;

public class SavePerson {
   public static void main(String[] args) throws Exception {
      // Read picture
      Path pathHomer = Paths.get("homer.jpg");
      byte[] pictureHomer = Files.readAllBytes(pathHomer);

      Path pathMarge = Paths.get("marge.jpg");
      byte[] pictureMarge = Files.readAllBytes(pathMarge);

      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Person homer = new Person();
      homer.setFirstName("Homer");
      homer.setLastName("Simpson");
      homer.setBirthDay(new GregorianCalendar());
      homer.setGender(GenderType.MALE);
      homer.setPicture(pictureHomer);
      homer.setComment("Some comment about Homer ");
      homer.setMarried(false);
      homer.setHomepage("www.thesimpsons.com");
      em.persist(homer);
      System.out.println(homer.getId());
      Person marge = new Person();
      marge.setFirstName("Marge");
      marge.setLastName("Simpson");
      marge.setBirthDay(new GregorianCalendar(2014, 5, 13));
      marge.setGender(GenderType.FEMALE);
      marge.setPicture(pictureMarge);
      marge.setComment("Some comment about Marge ");
      marge.setMarried(false);
      marge.setHomepage("www.thesimpsons.com");
      em.persist(marge);
      System.out.println(marge.getId());

      tx.commit();
      em.close();
      emf.close();
      System.out.println("Persons saved");
   }
}
