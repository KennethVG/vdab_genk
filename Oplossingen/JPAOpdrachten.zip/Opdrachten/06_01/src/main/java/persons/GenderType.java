package persons;

public enum GenderType {
   MALE,FEMALE;
}
