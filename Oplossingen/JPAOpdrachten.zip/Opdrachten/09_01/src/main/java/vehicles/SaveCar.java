package vehicles;

import java.util.*;

import javax.persistence.*;

public class SaveCar {
   public static void main(String[] args) {
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("course");
      EntityManager em = emf.createEntityManager();
      EntityTransaction tx = em.getTransaction();
      tx.begin();
      Car car = new Car();
      car.setBrand("Ford");
      car.setType("Fiesta");
      car.setPlate("1-AMD-116");
      car.setEntryIntoService(new GregorianCalendar(2019,1,1));
      car.setListPrice(23000.00F);
      car.setPower(100);      
      em.persist(car);
      tx.commit();
      em.close();
      emf.close();
      System.out.println("Saved");
   }
}
