package exercise4_06;

public class BMIService {
   public float calculateBMI(float height, float weight) {
      return weight/(height*height);
   }
}
