package exercise4_04;

public interface AddressService {
   public void registerAddress(AddressBean address);
}
