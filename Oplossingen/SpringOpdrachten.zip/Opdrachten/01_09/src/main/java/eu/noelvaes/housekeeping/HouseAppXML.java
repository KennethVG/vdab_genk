package eu.noelvaes.housekeeping;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HouseAppXML {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext();
		ctx.getEnvironment().setActiveProfiles("smallHouse");
		ctx.setConfigLocation("housekeeping.xml");
		ctx.refresh();
		DomesticService service = ctx.getBean("domesticService",
		   DomesticService.class);
		service.runHousehold();
		ctx.close();
	}
}
