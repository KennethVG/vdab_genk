package eu.noelvaes.housekeeping;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;

@Component("domesticService")
public class DomesticServiceImpl implements DomesticService {
   @Autowired
   @Qualifier("robot")
	private CleaningService cleaningService;
	
   @Autowired
   private GardeningService gardeningService;
		
	public void runHousehold() {
		System.out.println("Running household");
		cleaningService.clean();
		gardeningService.garden();
	}
	
}
