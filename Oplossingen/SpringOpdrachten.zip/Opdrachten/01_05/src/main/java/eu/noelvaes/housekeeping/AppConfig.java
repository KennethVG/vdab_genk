package eu.noelvaes.housekeeping;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
public class AppConfig {
}
