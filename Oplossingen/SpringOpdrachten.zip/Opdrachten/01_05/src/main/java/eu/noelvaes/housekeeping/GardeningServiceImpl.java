package eu.noelvaes.housekeeping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GardeningServiceImpl implements GardeningService{
	//@Autowired
	private GardeningTool tool;
	
//	@Autowired
//	public void setGardeningTool(GardeningTool tool) {
//		this.tool = tool;
//	}
    

	@Autowired
	public GardeningServiceImpl(GardeningTool tool) {
		this.tool = tool;
	}

	public void garden() {
   	System.out.println("Working in the garden.");
   	tool.doGardenJob();
   }
}
