package eu.noelvaes.housekeeping;

public interface CleaningService {
	public void clean();

}