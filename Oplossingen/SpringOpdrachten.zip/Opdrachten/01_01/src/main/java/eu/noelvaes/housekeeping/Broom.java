package eu.noelvaes.housekeeping;

public class Broom implements CleaningTool {
   public void doCleanJob() {
      System.out.println("Scrub scrub");
   }
}
