package eu.noelvaes.housekeeping;

public class VacuumCleaner implements CleaningTool {
   public void doCleanJob() {
      System.out.println("Zuuuuuuuuuuu");
   }
}
