package eu.noelvaes.housekeeping;

public interface CleaningTool {
   public void doCleanJob();
}
