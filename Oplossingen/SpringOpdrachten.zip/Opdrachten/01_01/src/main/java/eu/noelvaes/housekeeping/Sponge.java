package eu.noelvaes.housekeeping;

public class Sponge implements CleaningTool {
   public void doCleanJob() {
      System.out.println("Splash splash");
   }
}
