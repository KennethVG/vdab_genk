package eu.noelvaes.spring.beers;
import java.util.List;
import java.util.stream.Stream;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import eu.noelvaes.spring.beers.domain.*;

public class BeerApp {
	public static void main(String[] args) throws InterruptedException {
		ConfigurableApplicationContext ctx = SpringApplication.run(
		   BeerAppConfig.class, args);
		BeerRepository br = ctx.getBean("beerRepository",BeerRepository.class);
		BrewerRepository brr = ctx.getBean("brewerRepository",BrewerRepository.class);
		CategoryRepository cr = ctx.getBean("categoryRepository",CategoryRepository.class);
		
		System.out.println(br.findOne(20));
      System.out.println(br.findOne(21));
      System.out.println(br.getBeerById(21));
      
      
		System.out.println(brr.findOne(10));
		System.out.println(cr.findOne(5));
      
		for(Brewer brewer : brr.findAll()) {
			System.out.println(brewer);
		}

      System.out.println(br.count());
      System.out.println(br.exists(15));

      List<Beer> beers = br.findByAlcoholOrderByNameAsc(9);      
      beers.forEach(System.out::println);

      beers = br.findBeerByAlcoholBetween(5,8);      
      beers.forEach(System.out::println);

      beers = br.findBeerByAlcoholLessThan(8);      
      beers.forEach(System.out::println);

      beers = br.findBeerByAlcoholGreaterThan(5);      
      beers.forEach(System.out::println);

      beers = br.findByNameLikeOrderByName("Witkap%");      
      beers.forEach(System.out::println);

      beers = br.findFirst10ByAlcohol(9);      
      beers.forEach(System.out::println);

      Stream<Beer> bs = br.findByStockLessThan(100);      
      bs.forEach(System.out::println);
      //bs.close();
 
      br.updatePrice(0.02F);
	}
}
