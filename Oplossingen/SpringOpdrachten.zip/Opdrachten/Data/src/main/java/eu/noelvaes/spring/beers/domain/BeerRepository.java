package eu.noelvaes.spring.beers.domain;
import java.util.List;
import java.util.stream.Stream;
import javax.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.transaction.annotation.*;

@Transactional(readOnly=true)
public interface BeerRepository extends
   JpaRepository<Beer, Integer> {
	
   public default Beer getBeerById(int id) {
   	return findOne(id);
   }
   
   @Transactional(readOnly=false)
   public default void updateBeer(Beer b) {
   	save(b);
   }
	
	// @Query(name="findBeersByAlcohol")
	//@Lock(LockModeType.OPTIMISTIC)
	@Query(value = "select b from Beer b where b.alcohol=?1")
	public List<Beer> getBeerByAlcohol(float alcohol);
	public List<Beer> findByAlcoholOrderByNameAsc(float alcohol);
	public List<Beer> findBeerByAlcoholBetween(float min, float max);
	public List<Beer> findBeerByAlcoholGreaterThan(float min);
	public List<Beer> findBeerByAlcoholLessThan(float max);
	public List<Beer> findByAlcoholOrName(float alcohol, String name);
	public List<Beer> findByNameLikeOrderByName(String name);
	public List<Beer> findFirst10ByAlcohol(float alcohol);
	public Stream<Beer> findByStockLessThan(int stock);

	@Transactional
	@Modifying
	@Query("update Beer b set b.price=b.price*?1")
	public int updatePrice(float perc);
	
}