package eu.noelvaes.spring.beers.domain;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrewerRepository extends
   JpaRepository<Brewer, Integer> {
}