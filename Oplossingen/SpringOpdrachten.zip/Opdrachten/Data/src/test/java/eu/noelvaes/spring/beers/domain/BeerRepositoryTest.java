package eu.noelvaes.spring.beers.domain;
import static org.junit.Assert.assertEquals;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import eu.noelvaes.spring.beers.TestConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TestConfig.class)
@DirtiesContext
public class BeerRepositoryTest {
   @Autowired
   private BeerRepository repo;

   @Test
   public void testGetBeerById() {
      Beer beer = repo.getBeerById(1);
      assertEquals("TestBeer", beer.getName());
   }

   @Test
   public void testUpdateBeer() {
      Beer beer = repo.getBeerById(1);
      int stock = beer.getStock();
      beer.setStock(stock - 5);
      repo.updateBeer(beer);
      beer = repo.getBeerById(1);
      assertEquals(stock - 5, beer.getStock());
   }

   @Test
   public void testGetBeerByAlcohol() {
      List<Beer> beers = repo.getBeerByAlcohol(7);
      for (Beer b : beers) {
         assertEquals(7, b.getAlcohol(), 0.1F);
      }
   }
}
