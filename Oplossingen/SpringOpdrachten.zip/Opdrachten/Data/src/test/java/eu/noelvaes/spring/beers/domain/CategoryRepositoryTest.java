package eu.noelvaes.spring.beers.domain;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import eu.noelvaes.spring.beers.TestConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=TestConfig.class)
@DirtiesContext
public class CategoryRepositoryTest {
	@Autowired
	private CategoryRepository repo;
	
	@Test
	public void testGetCategoryById(){
		Category category = repo.findOne(1);
		assertEquals("TestCategory", category.getName());
	}

}
