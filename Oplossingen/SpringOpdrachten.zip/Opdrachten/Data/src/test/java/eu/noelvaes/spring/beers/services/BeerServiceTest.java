package eu.noelvaes.spring.beers.services;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.*;
import org.springframework.transaction.annotation.Transactional;
import eu.noelvaes.spring.beers.TestConfig;
import eu.noelvaes.spring.beers.domain.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=TestConfig.class)
@Transactional
public class BeerServiceTest {
	@Autowired
	private BeerRepository repo;
	
	@Autowired
	private BeerService bs;
	
	@BeforeTransaction
	public void beforeTransaction() {
		System.out.println("Before TX");
	}
	
	@AfterTransaction
	public void afterTransaction() {
		System.out.println("After TX");		
	}
	
	@Test
	@Commit
	public void testOrderBeer() throws InvalidBeerException, InvalidNumberException{
		bs.orderBeer(1, 10);
		Beer beer = repo.findOne(1);
		assertEquals(90, beer.getStock());
	}

	@Test(expected=InvalidBeerException.class)
	public void testInvalidBeer() throws InvalidBeerException, InvalidNumberException{
		bs.orderBeer(5, 10);
	}

	@Test(expected=InvalidNumberException.class)
	public void testInvalidNumber() throws InvalidBeerException, InvalidNumberException{
		bs.orderBeer(1, -10);
	}

}
