package eu.noelvaes.spring.beers.client;

import javax.jms.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.jms.core.*;
import org.springframework.stereotype.*;

@Component
public class BeerJmsSender {
   @Autowired
   private JmsTemplate jmsTemplate;

   public void orderBeers(final int[][] beers) {
      //jmsTemplate.send("BeerQueue",s -> s.createObjectMessage(beers));
      jmsTemplate.send("BeerQueue", new MessageCreator() {
         public Message createMessage(Session session)
            throws JMSException {
            return session.createObjectMessage(beers);
         }
      });
   }
}
