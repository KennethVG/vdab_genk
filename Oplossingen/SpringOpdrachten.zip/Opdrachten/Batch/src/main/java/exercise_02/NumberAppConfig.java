package exercise_02;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableBatchProcessing
public class NumberAppConfig {
	@Autowired
	private JobBuilderFactory jobBuilder;
	@Autowired
	private StepBuilderFactory stepBuilder;

	@Bean
	protected Step numberStep(NumberReader reader,
	   NumberProcessor processor, NumberWriter writer) {
		return stepBuilder.get("numberStep").<Integer, Integer> chunk(1)
		   .reader(reader).processor(processor).writer(writer).build();
	}

	@Bean
	public Job numberJob(Step numberStep, NumberJobListener listener) {
		return jobBuilder.get("numberJob").start(numberStep).listener(
		   listener).build();
	}
}