package exercise_02;
import org.springframework.batch.item.ItemReader;
import org.springframework.stereotype.Component;

@Component
public class NumberReader implements ItemReader<Integer>{
   private int[] numbers = {4,7,8,9,3,2,4};
   private int index = -1;   

	@Override
	public Integer read() {
		if(++index < numbers.length) {
			System.out.println("Read: " + numbers[index]);
			return numbers[index];
		} else {
			return null;
		}		
	}
}
