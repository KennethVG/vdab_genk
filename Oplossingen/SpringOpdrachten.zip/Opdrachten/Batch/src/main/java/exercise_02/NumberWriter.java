package exercise_02;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class NumberWriter implements ItemWriter<Integer> {
	public void write(List<? extends Integer> numbers) {
		System.out.print("Write: ");
		numbers.forEach(System.out::println);
	}
}
