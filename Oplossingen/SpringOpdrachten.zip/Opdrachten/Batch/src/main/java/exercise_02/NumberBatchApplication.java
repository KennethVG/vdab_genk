package exercise_02;

import java.util.*;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class NumberBatchApplication {

	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = SpringApplication.run(NumberAppConfig.class);

		Job job = ctx.getBean("numberJob", Job.class);
		JobLauncher jobLauncher = ctx.getBean("jobLauncher", JobLauncher.class);
		
		Map<String, JobParameter> params = new HashMap<>();
		params.put("name", new JobParameter("numberJob", true));
		JobParameters jobParameters = new JobParameters(params);

		JobExecution jobExecution = null;
				
		int trial = 1;
		do {
			System.out.println("Trial " + trial++);
			jobExecution = jobLauncher.run(job, jobParameters);
		} while (jobExecution.getStatus() == BatchStatus.FAILED);			
		//jobExecution = jobLauncher.run(job, jobParameters);
	}
}
