package eu.noelvaes.spring.batch.hello;

import org.springframework.batch.item.*;
import org.springframework.stereotype.Component;

@Component
public class HelloReader implements ItemReader<String>, ItemStream {
	private static final String INDEX = "HelloReader.index";
	private String[] lines = { "Homer", "Marge", "Bart", "Lisa", "Maggy" };
	private int index = -1;

	@Override
	public String read() {
		String s = null;
		if (++index < lines.length) {
			s = lines[index];
		}
		System.out.println("Read: " + s);
		return s;
	}

	public void open(ExecutionContext executionContext) {
		index = executionContext.getInt(INDEX, -1);
		System.out.println("Open");
	}

	
	public void update(ExecutionContext executionContext) {
		System.out.println("Update");
		executionContext.putInt(INDEX, index);
	}
	
	public void close() {
		System.out.println("Close");
	}
}
