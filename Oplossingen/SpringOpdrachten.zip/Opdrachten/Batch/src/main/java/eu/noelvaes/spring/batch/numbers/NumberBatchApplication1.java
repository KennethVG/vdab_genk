package eu.noelvaes.spring.batch.numbers;

import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SuppressWarnings("resource")
public class NumberBatchApplication1 {

	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = SpringApplication.run(
		   NumberAppConfig.class);

		Job job = ctx.getBean("numberJob", Job.class);
		JobLauncher jobLauncher = ctx.getBean("jobLauncher", JobLauncher.class);
		JobParameters jobParameters = new JobParameters();
		JobExecution jobExecution = jobLauncher.run(job, jobParameters);
	}
}
