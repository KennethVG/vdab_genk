package eu.noelvaes.spring.batch.hello;

public class HelloException extends RuntimeException {

	public HelloException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HelloException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public HelloException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HelloException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HelloException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
