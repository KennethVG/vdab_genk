package eu.noelvaes.spring.batch.hello;
import java.util.List;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class HelloWriter implements ItemWriter<String> {
	public void write(List<? extends String> lines) {
		System.out.println("Write: ");
		lines.forEach(System.out::println);
	}
}
