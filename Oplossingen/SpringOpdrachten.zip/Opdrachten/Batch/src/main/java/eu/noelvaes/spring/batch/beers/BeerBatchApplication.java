package eu.noelvaes.spring.batch.beers;
import java.util.*;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class BeerBatchApplication {
	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = SpringApplication.run(
		   BeerAppConfig.class);
		Random rand = new Random();
		Job job = ctx.getBean("beerJob", Job.class);
		JobLauncher jobLauncher = ctx.getBean("jobLauncher",
		   JobLauncher.class);
		Map<String, JobParameter> params = new HashMap<>();
		params.put("number", new JobParameter(rand.nextLong(), true));
		JobParameters jobParameters = new JobParameters(params);
		jobLauncher.run(job, jobParameters);
	}
}
