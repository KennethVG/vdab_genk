package eu.noelvaes.spring.batch.beers;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import eu.noelvaes.spring.batch.beers.domain.Beer;

@Component
public class BeerProcessor implements ItemProcessor<Beer, Beer> {
	public Beer process(Beer beer) {
		System.out.println("Process beer : " + beer.getId());
		beer.setStock(10);
		return beer;
	}
}
