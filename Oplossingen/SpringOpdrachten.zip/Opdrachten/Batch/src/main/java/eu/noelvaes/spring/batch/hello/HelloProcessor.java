package eu.noelvaes.spring.batch.hello;

import java.util.Random;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class HelloProcessor implements ItemProcessor<String,String> {
	private Random random = new Random();

	public String process(String item) {
//		if(random.nextInt(5) % 5 == 0) {
//			throw new HelloException("Random failure");
//		}
		System.out.println("Process: " + item);
		return "Hello " + item;
	}
}
