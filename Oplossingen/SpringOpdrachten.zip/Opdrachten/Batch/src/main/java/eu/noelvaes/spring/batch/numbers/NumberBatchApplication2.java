package eu.noelvaes.spring.batch.numbers;

import java.util.*;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

@SuppressWarnings("resource")
public class NumberBatchApplication2 {

   public static void main(String[] args) throws Exception {
		ApplicationContext ctx = SpringApplication.run(
		   NumberAppConfig.class);

      Job job = ctx.getBean("numberJob", Job.class);
      JobLauncher jobLauncher = ctx.getBean("jobLauncher", JobLauncher.class);

      Map<String, JobParameter> params = new HashMap<>();
      params.put("name", new JobParameter("job374", true));
      JobParameters jobParameters = new JobParameters(params);

      int trial = 1;
      JobExecution jobExecution = null;
      do {
         System.out.println("Trial " + trial++);
         jobExecution = jobLauncher.run(job, jobParameters);
      } while (jobExecution.getStatus() == BatchStatus.FAILED);
   }
}
