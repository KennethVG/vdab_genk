package eu.noelvaes.spring.batch.hello;

import org.springframework.batch.core.*;
import org.springframework.stereotype.Component;

@Component
public class HelloJobListener implements JobExecutionListener {

	public void afterJob(JobExecution jobExecution) {
		System.out.println("After Execution" + jobExecution.getJobParameters());
	}

	public void beforeJob(JobExecution jobExecution) {
		System.out.println("Before Execution " + jobExecution.getJobParameters());
	}
}
