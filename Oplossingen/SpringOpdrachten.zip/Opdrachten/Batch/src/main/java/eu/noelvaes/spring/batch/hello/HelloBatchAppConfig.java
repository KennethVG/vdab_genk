package eu.noelvaes.spring.batch.hello;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.SimpleAsyncTaskExecutor;

@SpringBootApplication
@EnableBatchProcessing
public class HelloBatchAppConfig {
	@Autowired
	private JobBuilderFactory jobBuilder;
	
	@Autowired
	private StepBuilderFactory stepBuilder;
	
	// @Bean
	// protected PlatformTransactionManager transactionManager() {
	// return new ResourcelessTransactionManager();
	// }
	// @Bean
	// protected JobRepository jobRepository(PlatformTransactionManager tm)
	// throws Exception {
	// MapJobRepositoryFactoryBean fact = new MapJobRepositoryFactoryBean(tm);
	// return fact.getObject();
	// }
	// @Bean
	// protected DataSource dataSource() {
	// BasicDataSource ds = new BasicDataSource();
	// ds.setDriverClassName("com.mysql.jdbc.Driver");
	// ds.setUrl("jdbc:mysql://noelvaes.eu:3306/StudentDB");
	// ds.setUsername("student");
	// ds.setPassword("student123");
	// return ds;
	// }

//	@Bean
//	protected JobLauncher jobLauncher(JobRepository jobRepository) {
//		SimpleJobLauncher launcher = new SimpleJobLauncher();
//		launcher.setJobRepository(jobRepository);
//		launcher.setTaskExecutor(new SimpleAsyncTaskExecutor());
//		return launcher;
//	}

	@Bean
	protected Step helloStep(HelloReader reader,
	   HelloProcessor processor, HelloWriter writer) {
		return stepBuilder.get("helloStep") // Create step builder
		   .<String, String> chunk(2)// Set chunk size
		   .reader(reader) // Set reader
		   .processor(processor) // Set processor
		   .writer(writer) // Set writer
		   .build(); // Build step
	}
	// @Bean
	// public Job helloJob(Step helloStep) {
	// return jobBuilder
	// .get("helloJob") // Create job builder
	// .start(helloStep) // Start job with a step
	// .build(); // Build job
	// }

	@Bean
	public Job helloJob(Step helloStep, HelloJobListener listener) {
		return jobBuilder.get("helloJob")
			              //.preventRestart()
			              .listener(listener)
			              .start(helloStep)
			              .build();
	}

	@Bean
	protected Step taskletStep(HelloTasklet tasklet) {
		return stepBuilder.get("taskletStep").tasklet(tasklet).build();
	}

	@Bean
	public Job taskletJob(Step taskletStep) {
		return jobBuilder.get("taskletJob").start(taskletStep).build();
	}

	@Bean
	protected Step step1(HelloTasklet tasklet) {
		return stepBuilder.get("step1").tasklet(tasklet).build();
	}

	@Bean
	protected Step step2(HelloTasklet tasklet) {
		return stepBuilder.get("step2").tasklet(tasklet).build();
	}

	@Bean
	protected Step step3(HelloTasklet tasklet) {
		return stepBuilder.get("step3").tasklet(tasklet).build();
	}

	@Bean
	public Job sequentialJob(Step step1, Step step2) {
		return jobBuilder.get("sequentialJob").start(step1).next(step2)
		   .build();
	}

	@Bean
	public Job conditionalJob(Step step1, Step step2, Step step3) {
		return jobBuilder.get("conditionalJob").start(step1).on("FAILED").to(step2).from(step1).on("*").to(step3)
			
			.build()
		   .build();
	}
	
	@Bean
	public Job parallelJob(Step step1, Step step2, Step step3) {
		Flow flow1 = new FlowBuilder<Flow>("flow1").start(step1)
		   .build();
		Flow flow2 = new FlowBuilder<Flow>("flow2").start(step2)
		   .build();
		return jobBuilder.get("parallelJob").start(flow1).split(
		   new SimpleAsyncTaskExecutor()).add(flow2).next(step3).build()
		   .build();
	}
}