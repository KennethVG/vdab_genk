package eu.noelvaes.spring.batch.hello;

import java.util.*;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class HelloBatchApplication {
	public static void main(String[] args) throws Exception {

		ApplicationContext ctx = SpringApplication.run(HelloBatchAppConfig.class);

		Random rand = new Random();

		//Job job = ctx.getBean("helloJob", Job.class);
		//Job job = ctx.getBean("taskletJob", Job.class);
		//Job job = ctx.getBean("sequentialJob", Job.class);
		//Job job = ctx.getBean("conditionalJob", Job.class);
		Job job = ctx.getBean("parallelJob", Job.class);
		
		JobLauncher jobLauncher = ctx.getBean("jobLauncher", JobLauncher.class);
		Map<String, JobParameter> params = new HashMap<>();
		params.put("number", new JobParameter(rand.nextLong(), true));
		params.put("comment", new JobParameter("First Job"));
		JobParameters jobParameters = new JobParameters(params);
		
//      JobParameters jobParameters = new JobParameters();
		JobExecution jobExecution = jobLauncher.run(job,jobParameters);
		
		//
//		//int trial = 1;
//		JobExecution jobExecution = null;
		//do {
			//System.out.println("Trial " + trial++);
//			jobExecution = jobLauncher.run(job, jobParameters);
		//} while (jobExecution.getStatus() == BatchStatus.FAILED);
	
	
	}

}
