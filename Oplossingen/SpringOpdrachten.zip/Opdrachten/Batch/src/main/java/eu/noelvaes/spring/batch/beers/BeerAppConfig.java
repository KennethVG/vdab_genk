package eu.noelvaes.spring.batch.beers;
import javax.persistence.EntityManagerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.batch.item.*;
import org.springframework.batch.item.database.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import eu.noelvaes.spring.batch.beers.domain.Beer;

@SpringBootApplication
@EnableBatchProcessing
public class BeerAppConfig {
	@Autowired
	private JobBuilderFactory jobBuilder;
	@Autowired
	private StepBuilderFactory stepBuilder;
	
	@Bean
	protected ItemReader<Beer> beerReader(EntityManagerFactory emf) {
		JpaPagingItemReader<Beer> reader = new JpaPagingItemReader<>();
		reader.setEntityManagerFactory(emf);
		reader.setQueryString(
		   "select b from Beer as b where b.stock < 0 ");
		reader.setPageSize(10);
		return reader;
	}

	@Bean
	protected ItemWriter<Beer> beerWriter(EntityManagerFactory emf) {
		JpaItemWriter<Beer> writer = new JpaItemWriter<>();
		writer.setEntityManagerFactory(emf);
		return writer;
	}

	@Bean
	protected Step backorderStep(ItemReader<Beer> beerReader,
	   BeerProcessor beerProcessor, ItemWriter<Beer> beerWriter) {
		return stepBuilder.get("backorderStep")
		                  .<Beer, Beer> chunk(10)
		                  .reader(beerReader)
		                  .processor(beerProcessor)
		                  .writer(beerWriter)
		                  .build();
	}
	
	@Bean
	public Job beerJob(Step backorderStep) {
		return jobBuilder.get("beerJob")
		                 .start(backorderStep)
		                 .build();
	}
}