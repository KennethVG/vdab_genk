package exercise_04;

import org.springframework.batch.core.*;
import org.springframework.stereotype.Component;

@Component
public class NumberJobListener implements JobExecutionListener {

	public void afterJob(JobExecution jobExecution) {
		System.out.println("After Execution" + jobExecution.getJobParameters());
	}

	public void beforeJob(JobExecution jobExecution) {
		System.out.println("Before Execution " + jobExecution.getJobParameters());
	}
}
