package exercise_05;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableBatchProcessing
public class NumberAppConfig {
	@Autowired
	private JobBuilderFactory jobBuilder;
	@Autowired
	private StepBuilderFactory stepBuilder;

	@Bean
	protected Step numberStep(NumberReader reader,
	   NumberProcessor processor, NumberWriter writer) {
		return stepBuilder.get("numberStep")
		                  .<Integer, Integer> chunk(1)
		                  .faultTolerant()
		                     .retry(NumberException.class)
		                     .retryLimit(2)
		                  .reader(reader)
		                  .processor(processor)
		                  .writer(writer)
		                  .build();
	}

	@Bean
	protected Step finishedStep(FinishedTasklet finishedTasklet) {
		return stepBuilder.get("finishedStep")
		                  .tasklet(finishedTasklet)
		                  .build();
	}

	@Bean
	protected Step failedStep(FailedTasklet failedTasklet) {
		return stepBuilder.get("failedStep")
		                  .tasklet(failedTasklet)
		                  .build();
	}

	@Bean
	public Job numberJob(Step numberStep, NumberJobListener listener,
	   Step finishedStep, Step failedStep) {
		return jobBuilder.get("numberJob")
		                 .start(numberStep)
		                    .on("FAILED")
		                       .to(failedStep)
		                       .on("*")
		                          .fail()
		                 .from(numberStep)
		                    .on("COMPLETED")
		                       .to(finishedStep)
		                 .build()
		                 .listener(listener)
		                 .build();
	}
}