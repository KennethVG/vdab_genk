package exercise_05;

import org.springframework.batch.item.*;
import org.springframework.stereotype.Component;

@Component
public class NumberReader implements ItemReader<Integer>, ItemStream {
   private static final String INDEX = "NumberReader.index";
   private int[] numbers = { 4, 7, 8, 9, 3, 2, 4 };
   private int index = -1;

   @Override
   public Integer read() {
      if (++index < numbers.length) {
         System.out.println("Read: " + numbers[index]);
         return numbers[index];
      } else {
         return null;
      }
   }

   public void open(ExecutionContext executionContext) {
      index = executionContext.getInt(INDEX, -1);
      System.out.println("Open");
   }

   public void update(ExecutionContext executionContext) {
      System.out.println("Update");
      executionContext.putInt(INDEX, index);
   }

   public void close() {
      System.out.println("Close");
   }
}
