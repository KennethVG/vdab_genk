package exercise_03;

public class NumberException extends Exception {
	private static final long serialVersionUID = 6961332027856462426L;

	public NumberException() {
	}

	public NumberException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NumberException(String message, Throwable cause) {
		super(message, cause);
	}

	public NumberException(String message) {
		super(message);
	}

	public NumberException(Throwable cause) {
		super(cause);
	}
}
