package exercise_03;

import java.util.Random;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class NumberProcessor implements ItemProcessor<Integer,Integer> {
	private Random random = new Random();
	
	public Integer process(Integer item) throws NumberException {
		if(random.nextBoolean()) {
			throw new NumberException("Random failure");
		}
		System.out.println("Process: " + item);
		return item * item;
	}
}
