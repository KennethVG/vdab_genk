package exercise_01;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class NumberProcessor implements ItemProcessor<Integer,Integer> {
	
	public Integer process(Integer item) {
		System.out.println("Process: " + item);
		return item * item;
	}
}
