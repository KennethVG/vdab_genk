package exercise_01;

import org.springframework.boot.SpringApplication;

public class NumberBatchApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(NumberAppConfig.class);
	}
}
