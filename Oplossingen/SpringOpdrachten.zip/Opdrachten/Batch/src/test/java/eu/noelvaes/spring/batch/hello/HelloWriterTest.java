package eu.noelvaes.spring.batch.hello;

import java.io.IOException;
import java.util.*;

import org.junit.*;

public class HelloWriterTest {
	private HelloWriter writer;
   private List<String> lines;
	
	@Before
	public void setup() throws IOException {
		writer = new HelloWriter();
		lines = Arrays.asList("Hello Homer","Hello Marge");
	}
	
	@Test
	public void test() throws IOException {
		writer.write(lines);
	}

}
