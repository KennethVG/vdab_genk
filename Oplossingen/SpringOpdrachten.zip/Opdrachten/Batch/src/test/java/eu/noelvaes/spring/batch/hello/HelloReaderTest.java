package eu.noelvaes.spring.batch.hello;

import java.io.IOException;

import org.junit.*;


public class HelloReaderTest {
   private HelloReader reader;
	
	@Before
	public void setup() throws IOException {
		reader = new HelloReader();
	}
	
	
	@Test
	public void testRead() {
		Assert.assertEquals("Homer", reader.read());
		Assert.assertEquals("Marge", reader.read());
		Assert.assertEquals("Bart", reader.read());
		Assert.assertEquals("Lisa", reader.read());
		Assert.assertEquals("Maggy", reader.read());		
	}

}
