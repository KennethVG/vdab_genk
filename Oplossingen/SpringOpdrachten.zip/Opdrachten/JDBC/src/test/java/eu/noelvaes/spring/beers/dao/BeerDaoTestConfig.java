package eu.noelvaes.spring.beers.dao;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeerDaoTestConfig {
}
