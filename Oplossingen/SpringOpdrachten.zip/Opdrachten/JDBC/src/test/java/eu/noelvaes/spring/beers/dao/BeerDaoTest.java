package eu.noelvaes.spring.beers.dao;

import java.util.List;
import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=BeerDaoTestConfig.class)
@DirtiesContext
public class BeerDaoTest {
	
	@Autowired
	private BeerDao dao;
	
	@Test
	public void testGetBeerById() {
		String beer = dao.getBeerById(1);
		Assert.assertEquals("TestBeer 7.0 2.75 100", beer);	
	}
	
	@Test
	public void testSetStock() {
		dao.setStock(1, 50);
		String beer = dao.getBeerById(1);
		Assert.assertEquals("TestBeer 7.0 2.75 50", beer);	
	}

	@Test
	public void testGetBeersByAlcohol() {
		List<String> beers = dao.getBeerByAlcohol(7.0F);
		Assert.assertEquals(1,beers.size());	
	}
	
}
