package eu.noelvaes.spring.beers.dao;

import java.util.*;

public interface BeerDao {
   public String getBeerById(int id);
   public List<String> getBeerByAlcohol(float alcohol);
   public void setStock(int id, int stock);

}