package eu.noelvaes.spring.beers.dao;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("beerDao")
public class BeerDaoImpl implements BeerDao {
	private final static String QUERY_ID = "SELECT Name, Alcohol, Price, Stock FROM Beers WHERE Id=? ";
	private final static String QUERY_ALCOHOL = "SELECT Name, Alcohol, Price, Stock FROM Beers WHERE Alcohol=? ";
	private final static String UPDATE_STOCK = "UPDATE Beers SET Stock = ? WHERE Id=? ";
	private JdbcTemplate template;

	@Autowired
	public void setJdbcTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public String getBeerById(int id) {
		Map<String, Object> result = template.queryForMap(QUERY_ID, id);
		return String.format("%s %s %s %s", result.get("name"), result
		   .get("alcohol"), result.get("price"), result.get("stock"));
	}

	public List<String> getBeerByAlcohol(float alcohol) {
		List<Map<String, Object>> result = template.queryForList(
		   QUERY_ALCOHOL, alcohol);
		return result.stream()
			          .map(b -> String.format("%s %s %s",
			         	                      b.get("name"),
			         	                      b.get("alcohol"),
			         	                      b.get("price"),
			         	                      b.get("stock")))
		   .collect(Collectors.toList());
	}

	public void setStock(int id, int stock) {
		template.update(UPDATE_STOCK, stock, id);
	}
}
