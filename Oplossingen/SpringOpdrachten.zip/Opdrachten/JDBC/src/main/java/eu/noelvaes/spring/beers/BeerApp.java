package eu.noelvaes.spring.beers;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import eu.noelvaes.spring.beers.dao.BeerDao;

public class BeerApp {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(
		   BeerAppConfig.class, args);
		BeerDao dao = ctx.getBean("beerDao", BeerDao.class);
      System.out.println(dao.getBeerById(20));
      dao.setStock(10,200);      
      List<String> beers = dao.getBeerByAlcohol(8F);
      beers.forEach(System.out::println);
	}
}
