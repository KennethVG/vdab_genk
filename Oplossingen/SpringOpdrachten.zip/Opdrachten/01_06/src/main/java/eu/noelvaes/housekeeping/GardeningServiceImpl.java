package eu.noelvaes.housekeeping;

import javax.annotation.*;
import org.springframework.stereotype.Component;

@Component
public class GardeningServiceImpl implements GardeningService{
	private GardeningTool tool;	
	
	//@Autowired
	@Resource(name="lawnMower")
	public void setGardeningTool(GardeningTool tool) {
		this.tool = tool;
	}
   
	@PostConstruct
	public void init() {
		System.out.println("GardenService preparing for work.");
	}

   @PreDestroy
   public void destroy() {
   	System.out.println("GardenService cleaning up.");
   }
	
	public void garden() {
   	System.out.println("Working in the garden.");
   	tool.doGardenJob();
   }
}
