package eu.noelvaes.spring.beers;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeerAppConfig {
}
