package eu.noelvaes.spring.beers;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

public class BeerApp {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(
		   BeerAppConfig.class, args);
	}
}
