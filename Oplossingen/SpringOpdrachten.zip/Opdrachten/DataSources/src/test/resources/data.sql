USE StudentTestDB;

INSERT INTO Brewers VALUES (1,'TestBrewer','TestStreet',1000,'TestCity',10000);
INSERT INTO Categories VALUES (1,'TestCategory');
INSERT INTO Beers VALUES (1,'TestBeer',1,1,2.75,100,7,0,NULL);
