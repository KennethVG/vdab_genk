package eu.noelvaes.housekeeping;

public class VacuumCleaner implements CleaningTool {
	public VacuumCleaner() {
		System.out.println("VacuumCleaner: constructor");
	}

   public void doCleanJob() {
      System.out.println("Zuuuuuuuuuuu");
   }
}
