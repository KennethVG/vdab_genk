package eu.noelvaes.housekeeping;

public class Sponge implements CleaningTool {
	public Sponge() {
		System.out.println("Sponge: constructor");
	}

   public void doCleanJob() {
      System.out.println("Splash splash");
   }
}
