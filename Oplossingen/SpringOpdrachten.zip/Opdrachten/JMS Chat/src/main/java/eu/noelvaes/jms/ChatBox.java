package eu.noelvaes.jms;

public interface ChatBox {
   public void setChatReceiver(ChatReceiver listener);
   public void sendMessage(String name, String message);
}
