package eu.noelvaes.jms;

import java.awt.*;
import java.awt.event.*;

import javax.annotation.*;
import javax.swing.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;

@Component("chatBoxPanel")
public class ChatBoxPanel extends JPanel implements ChatReceiver,
      ActionListener {
   private ChatBox chatBox;
   private JTextArea messages = null;
   private JPanel bottomPanel = null;
   private JTextField message = null;
   private JButton sendButton = null;
   private JPanel topPanel = null;
   private JLabel jLabel = null;
   private JTextField userName = null;
   private JScrollPane messagesPane = null;

   @Autowired(required = true)
   public void setChatBox(ChatBox chatBox) {
      this.chatBox = chatBox;
   }

   @PostConstruct
   public void init() {
      this.setLayout(new BorderLayout());
      this.setSize(300, 200);
      userName = new JTextField();
      jLabel = new JLabel();
      topPanel = new JPanel();
      topPanel.setLayout(new BorderLayout());
      jLabel.setText("Username:");
      topPanel.add(jLabel, java.awt.BorderLayout.WEST);
      topPanel.add(userName, java.awt.BorderLayout.CENTER);
      sendButton = new JButton();
      sendButton.setText("Send");
      sendButton.addActionListener(this);

      message = new JTextField();
      message.addActionListener(this);
      bottomPanel = new JPanel();
      bottomPanel.setLayout(new BorderLayout());
      bottomPanel.add(message, java.awt.BorderLayout.CENTER);
      bottomPanel.add(sendButton, java.awt.BorderLayout.EAST);
      this.add(bottomPanel, java.awt.BorderLayout.SOUTH);
      this.add(topPanel, java.awt.BorderLayout.NORTH);
      messagesPane = new JScrollPane();
      messages = new JTextArea();
      messages.setEditable(false);
      messagesPane.setViewportView(messages);
      this.add(messagesPane, java.awt.BorderLayout.CENTER);
   }

   public void receiveMessage(String name, String message) {
      messages.append(name + ": " + message + "\n");
      JScrollBar sb = messagesPane.getVerticalScrollBar();
      sb.setValue(sb.getMaximum());
   }

   @Override
   public void actionPerformed(ActionEvent e) {
      chatBox.sendMessage(userName.getText(), message.getText());
      message.setText("");
   }
}
