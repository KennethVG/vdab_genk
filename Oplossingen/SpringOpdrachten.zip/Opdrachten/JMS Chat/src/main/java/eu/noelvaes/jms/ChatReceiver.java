package eu.noelvaes.jms;

public interface ChatReceiver {
   public void receiveMessage(String name, String message);
}
