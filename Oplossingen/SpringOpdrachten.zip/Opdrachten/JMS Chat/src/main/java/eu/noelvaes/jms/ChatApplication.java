package eu.noelvaes.jms;

import java.awt.BorderLayout;
import javax.annotation.PostConstruct;
import javax.swing.JFrame;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class ChatApplication extends JFrame {
   private ChatBoxPanel chatBox = null;

   public ChatApplication() {
      super("Chatbox Noël");
   }
   
   @Autowired
   public void setChatBoxPanel(ChatBoxPanel chatBox) {
      this.chatBox = chatBox;
   }

   @PostConstruct
   public void init() {
      setSize(365, 200);
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setLayout(new BorderLayout());
      add(chatBox, BorderLayout.CENTER);
      setVisible(true);
   }

   public static void main(String[] args) {
      SpringApplication.run(ChatApplication.class, args);     
   }
}
