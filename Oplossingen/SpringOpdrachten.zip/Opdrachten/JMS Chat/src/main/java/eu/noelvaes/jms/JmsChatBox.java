package eu.noelvaes.jms;
import javax.jms.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component("chatBoxBean")
public class JmsChatBox implements ChatBox {
   private static final String TOPIC = "chatroom";
   private JmsTemplate jmsTemplate;
   private ChatReceiver listener;

   @Autowired
   public void setChatReceiver(ChatReceiver listener) {
      this.listener = listener;
   }

   @Autowired
   public void setJmsTemplate(JmsTemplate jmsTemplate) {
      this.jmsTemplate = jmsTemplate;
   }
   
   @Autowired
   public void configure(DefaultJmsListenerContainerFactory fact) {
      fact.setPubSubDomain(true);
   }
   
   @JmsListener(destination = TOPIC)
   public void onMessage(Message msg) {
      if (listener == null)
         return;
      try {
         if (msg instanceof TextMessage) {
            TextMessage tm = (TextMessage) msg;
            String name = tm.getStringProperty("username");
            String message = tm.getText();
            listener.receiveMessage(name, message);
         }
      } catch (JMSException e) {
         System.err.println("JMS error while receiving message: "
            + e.getMessage());
      }
   }

   public void sendMessage(final String name,
      final String message) {
      jmsTemplate.setPubSubDomain(true);
      jmsTemplate.send(TOPIC, s -> {
         TextMessage msg = s.createTextMessage(message);
         msg.setStringProperty("username", name);
         return msg;
      });
   }
}
