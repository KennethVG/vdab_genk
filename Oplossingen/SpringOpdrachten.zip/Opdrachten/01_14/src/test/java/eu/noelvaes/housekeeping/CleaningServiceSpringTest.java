package eu.noelvaes.housekeeping;

import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.*;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=CleaningServiceSpringTest.class)
@DirtiesContext
@TestPropertySource(properties={"rate=9"})
public class CleaningServiceSpringTest {
   
   @Autowired
   private CleaningService testCleaner;
   
   @Autowired
   private CleaningToolMock mock;
      
   @Test
   public void testDoJob() {
      testCleaner.clean();
      Assert.assertTrue(mock.isCalled());
   }
   
   
   @Bean
   public CleaningToolMock mock() {
      return new CleaningToolMock();
   }
   
   @Bean
   public CleaningService testCleaner() {
      CleaningServiceImpl cs = new CleaningServiceImpl();
      cs.setCleaningTool(mock());
      return cs;
   }
   
   @Bean
   public static PropertySourcesPlaceholderConfigurer propConfig() {
      return new PropertySourcesPlaceholderConfigurer();
   }
}
