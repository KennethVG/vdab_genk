package eu.noelvaes.housekeeping;

import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class CleaningServiceTestConfig {
   @Bean
   public CleaningToolMock mock() {
      return new CleaningToolMock();
   }
   
   @Bean
   public CleaningService testCleaner() {
      CleaningServiceImpl cs = new CleaningServiceImpl();
      cs.setCleaningTool(mock());
      return cs;
   }
   
	@Bean
	public static PropertySourcesPlaceholderConfigurer propConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
