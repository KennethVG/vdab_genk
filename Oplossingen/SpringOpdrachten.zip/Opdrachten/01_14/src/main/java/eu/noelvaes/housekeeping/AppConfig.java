package eu.noelvaes.housekeeping;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.*;
import org.springframework.context.support.*;

@Configuration
@ComponentScan
@PropertySource("classpath:application.properties")
@EnableAspectJAutoProxy
public class AppConfig {
	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
		ms.setBasename("housekeeping");
		return ms;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
