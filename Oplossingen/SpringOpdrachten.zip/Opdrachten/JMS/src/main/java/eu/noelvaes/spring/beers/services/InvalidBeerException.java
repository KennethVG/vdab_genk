package eu.noelvaes.spring.beers.services;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public class InvalidBeerException extends Exception {

   public InvalidBeerException() {
      super();
   }

   public InvalidBeerException(String message, Throwable cause) {
      super(message, cause);
   }

   public InvalidBeerException(String message) {
      super(message);
   }

   public InvalidBeerException(Throwable cause) {
      super(cause);
   }
}
