package eu.noelvaes.spring.beers.web;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import eu.noelvaes.spring.beers.domain.*;
import eu.noelvaes.spring.beers.services.*;

@RestController
public class BeerRestController {
   @Autowired
   private BeerService service;
   @Autowired
   private BeerRepository repository;

   @RequestMapping(value = "/beers/{id}", method = RequestMethod.GET, produces = {
      "application/xml", "application/json" })
   public Beer getBeerById(@PathVariable("id") int id) {
      System.out.println("GET id: " + id);
      return repository.findOne(id);
   }

   @RequestMapping(value = "/beers", method = RequestMethod.GET, produces = {
      "application/xml", "application/json" })
   public BeerList getBeersByAlcohol(
      @RequestParam("alcohol") float alcohol) {
      System.out.println("GET alcohol: " + alcohol);
      List<Beer> beers = repository.getBeerByAlcohol(alcohol);
      return new BeerList(beers);
   }

   @RequestMapping(value = "/orders", method = RequestMethod.POST, consumes = { "application/xml",
         "application/json" }, produces = "text/plain")
   public ResponseEntity<String> order(@RequestBody BeerOrder order) {
      System.out.println("ORDER : " + order);
      try {
         service.orderBeer(order.getBeerId(), order.getAmount());
      } catch (InvalidBeerException | InvalidNumberException e) {
         return new ResponseEntity<String>("NOK",HttpStatus.BAD_REQUEST);
      }
      return new ResponseEntity<String>("OK",HttpStatus.OK);
   }
}
