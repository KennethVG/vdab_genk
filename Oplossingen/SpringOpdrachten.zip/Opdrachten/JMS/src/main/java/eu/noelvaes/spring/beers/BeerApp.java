package eu.noelvaes.spring.beers;
import org.springframework.boot.SpringApplication;


public class BeerApp {
	public static void main(String[] args) {
		SpringApplication.run(BeerAppConfig.class, args);
	}
}
