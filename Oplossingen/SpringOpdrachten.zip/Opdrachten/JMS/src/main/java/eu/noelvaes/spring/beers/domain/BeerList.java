package eu.noelvaes.spring.beers.domain;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BeerList {
   private List<Beer> list;

   public BeerList() {      
   }
   
   public BeerList(List<Beer> list) {
      this.list = list;
   }

   public List<Beer> getList() {
      return list;
   }

   public void setList(List<Beer> list) {
      this.list = list;
   }
}
