package eu.noelvaes.spring.beers.domain;
import java.util.List;
import org.springframework.data.jpa.repository.*;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly=true)
public interface BeerRepository extends
   JpaRepository<Beer, Integer> {
	// @Query(name="findBeersByAlcohol")
	//@Query(value = "select b from Beer b where b.alcohol=?1")
	public List<Beer> getBeerByAlcohol(float alcohol);
	public List<Beer> findByAlcoholOrderByNameAsc(float alcohol);
	public List<Beer> findBeerByAlcoholBetween(float min, float max);
	public List<Beer> findBeerByAlcoholGreaterThan(float min);
	public List<Beer> findBeerByAlcoholLessThan(float max);
	public List<Beer> findByAlcoholOrName(float alcohol, String name);
	public List<Beer> findByNameLike(String name);
	public List<Beer> findFirst10ByAlcohol(float alcohol);

	//@Transactional(propagation=Propagation.NEVER)
	//public Stream<Beer> findByStockLessThan(int stock);

	@Transactional
	@Modifying
	@Query("update Beer b set b.price=b.price*?1")
	public int updatePrice(float perc);
	
}