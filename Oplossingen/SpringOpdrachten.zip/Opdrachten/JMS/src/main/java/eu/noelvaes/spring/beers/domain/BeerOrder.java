package eu.noelvaes.spring.beers.domain;

import javax.xml.bind.annotation.*;

@XmlRootElement
public class BeerOrder {
   private int beerId;
   private int amount;

   public BeerOrder() {
   }

   public BeerOrder(int beerId, int amount) {
      this.beerId = beerId;
      this.amount = amount;
   }

   public int getBeerId() {
      return beerId;
   }

   public void setBeerId(int beerId) {
      this.beerId = beerId;
   }

   public int getAmount() {
      return amount;
   }

   public void setAmount(int amount) {
      this.amount = amount;
   }

   @Override
   public String toString() {
      return String.format("BeerOrder [beerId=%s, amount=%s]", beerId, amount);
   }

}
