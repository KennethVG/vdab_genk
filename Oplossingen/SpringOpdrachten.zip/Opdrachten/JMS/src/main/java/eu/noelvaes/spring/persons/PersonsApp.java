package eu.noelvaes.spring.persons;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonsApp {
	public static void main(String[] args) {
		SpringApplication.run(PersonsApp.class, args);
	}
}
