package eu.noelvaes.housekeeping.aspects;


public class MusicMakerImpl implements MusicMaker { 
   public void makeMusic() {
      System.out.println("I want to break free...");
   }
}
