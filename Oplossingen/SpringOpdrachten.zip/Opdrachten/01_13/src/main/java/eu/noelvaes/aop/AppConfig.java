package eu.noelvaes.aop;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
@EnableAspectJAutoProxy
public class AppConfig {
}
