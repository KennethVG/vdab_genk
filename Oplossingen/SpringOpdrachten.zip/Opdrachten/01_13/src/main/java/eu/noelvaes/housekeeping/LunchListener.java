package eu.noelvaes.housekeeping;

public interface LunchListener {
	void onLunchEvent(LunchEvent e);
}