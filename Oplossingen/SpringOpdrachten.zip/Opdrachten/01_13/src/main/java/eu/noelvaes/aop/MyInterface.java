package eu.noelvaes.aop;

public interface MyInterface {
   public String sayHello(String name);
   public String sayGoodbye(String name);
}
