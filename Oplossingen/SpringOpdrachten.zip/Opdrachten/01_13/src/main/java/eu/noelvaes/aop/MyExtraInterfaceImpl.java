package eu.noelvaes.aop;

public class MyExtraInterfaceImpl implements MyExtraInterface {
   public String sayGoodnight(String name) {
      return "Goodnight " + name;
   }
}
