package eu.noelvaes.aop;

public interface MyExtraInterface {
   public String sayGoodnight(String name);
}
