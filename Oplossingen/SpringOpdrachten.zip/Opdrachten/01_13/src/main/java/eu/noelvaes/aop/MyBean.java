package eu.noelvaes.aop;

import org.springframework.stereotype.*;

@Component
public class MyBean implements MyInterface{
   public String sayHello(String name) {
      return "Hello " +  name;
   }

   public String sayGoodbye(String name) {
      return "Goodbye " +  name;
   }
}
