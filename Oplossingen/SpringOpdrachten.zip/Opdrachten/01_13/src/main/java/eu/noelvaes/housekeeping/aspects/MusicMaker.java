package eu.noelvaes.housekeeping.aspects;

public interface MusicMaker {
   public void makeMusic();
}
