package eu.noelvaes.aop;

import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.*;

@Component
@Aspect
public class MyAspect {
   @DeclareParents(value = "eu.noelvaes.aop.MyBean", defaultImpl = eu.noelvaes.aop.MyExtraInterfaceImpl.class)
   public static MyExtraInterface mixin;

   @Before("execution(* *.sayHello(..))")
   public void before() {
      System.out.println("Before 1");
   }

   @AfterReturning(value = "execution(* *.sayHello(..))", returning = "returnValue")
   public void afterReturning(String returnValue) {
      System.out.println("AfterReturning " + returnValue);
   }

   @AfterThrowing(value = "execution(* *.sayHello(..))", throwing = "ex")
   public void afterException(Exception ex) {
      System.out.println("AfterException " + ex.getMessage());
   }

   @After("execution(* *.sayHello(..))")
   public void after() {
      System.out.println("After");
   }

   @Before("execution(String eu.noelvaes.aop.MyBean.sayGoodbye(String))")
   public void beforeGoodbye() {
      System.out.println("Before goodbye");
   }

   // @Before("execution(* *.sayHello(..)) && args(name)")
   public void beforeWithArgs(String name) {
      System.out.println("Before with argument " + name);
   }

   // @Before("execution(* *.sayHello(..))")
   public void beforeWithJoinPoint(JoinPoint jp) {
      System.out.println("Before with target " + jp.getTarget());
   }

   // @Around("execution(* *.sayHello(..))")
   public Object around(ProceedingJoinPoint pjp) throws Throwable {
      System.out.println("Before proceeding");
      Object returnValue = pjp.proceed();
      System.out.println("After proceeding");
      return returnValue;
   }

}
