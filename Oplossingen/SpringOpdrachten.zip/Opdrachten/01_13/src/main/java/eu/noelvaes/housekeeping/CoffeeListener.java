package eu.noelvaes.housekeeping;
import org.springframework.context.event.EventListener;

public interface CoffeeListener {
	void onCoffeeEvent(CoffeeEvent e);
}