package eu.noelvaes.aop;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyApp {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = new AnnotationConfigApplicationContext(
		   AppConfig.class);
		MyInterface bean = ctx.getBean("myBean", MyInterface.class);
		System.out.println(bean.sayHello("Homer"));
		System.out.println(bean.sayGoodbye("Homer"));
		MyExtraInterface bean2 = ctx.getBean("myBean",
		   MyExtraInterface.class);
		System.out.println(bean2.sayGoodnight("Homer"));
		ctx.close();
	}
}
