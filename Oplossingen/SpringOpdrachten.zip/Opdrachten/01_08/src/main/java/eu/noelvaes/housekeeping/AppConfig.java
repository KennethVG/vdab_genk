package eu.noelvaes.housekeeping;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@ComponentScan
@PropertySource("classpath:application.properties")
public class AppConfig {
	@Bean
	public static PropertySourcesPlaceholderConfigurer propConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
