package eu.noelvaes.housekeeping;

public interface GardeningService {
	public void garden();
}