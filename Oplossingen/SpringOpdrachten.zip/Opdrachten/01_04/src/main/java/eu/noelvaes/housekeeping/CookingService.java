package eu.noelvaes.housekeeping;

public class CookingService {

   public void cook() {
   	System.out.println("Cooking");
   }

   
}
