package eu.noelvaes.housekeeping;

public class LawnMower implements GardeningTool {
	public void doGardenJob() {
		System.out.println("Mowing the lawn");
	}
}
