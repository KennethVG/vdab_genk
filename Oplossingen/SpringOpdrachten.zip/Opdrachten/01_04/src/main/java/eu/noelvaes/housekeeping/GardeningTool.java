package eu.noelvaes.housekeeping;

public interface GardeningTool {
	public void doGardenJob();
}
