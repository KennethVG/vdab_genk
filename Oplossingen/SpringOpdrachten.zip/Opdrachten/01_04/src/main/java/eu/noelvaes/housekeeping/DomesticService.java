package eu.noelvaes.housekeeping;

public interface DomesticService {

	void runHousehold();

}