package eu.noelvaes.housekeeping;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
@Order(2)
@Profile("!smallHouse")
public class VacuumCleaner implements CleaningTool {
	public VacuumCleaner() {
		System.out.println("VacuumCleaner: constructor");
	}

   public void doCleanJob() {
      System.out.println("Zuuuuuuuuuuu");
   }

}
