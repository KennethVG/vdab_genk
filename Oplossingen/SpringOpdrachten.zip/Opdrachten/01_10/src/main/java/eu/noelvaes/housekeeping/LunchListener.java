package eu.noelvaes.housekeeping;

import org.springframework.context.event.EventListener;

public interface LunchListener {
	@EventListener
	public void onLunchEvent(LunchEvent e);
}