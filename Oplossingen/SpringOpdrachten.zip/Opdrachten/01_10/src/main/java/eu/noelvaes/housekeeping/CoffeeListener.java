package eu.noelvaes.housekeeping;
import org.springframework.context.event.EventListener;

public interface CoffeeListener {
	@EventListener
	public void onCoffeeEvent(CoffeeEvent e);
}