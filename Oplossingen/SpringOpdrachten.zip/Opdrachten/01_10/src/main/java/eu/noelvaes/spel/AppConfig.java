package eu.noelvaes.spel;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
public class AppConfig {
}
