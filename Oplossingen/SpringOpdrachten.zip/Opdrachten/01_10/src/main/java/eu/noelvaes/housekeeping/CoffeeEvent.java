package eu.noelvaes.housekeeping;

public class CoffeeEvent {
}
