package eu.noelvaes.hardware;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
public class AppConfig {
}
